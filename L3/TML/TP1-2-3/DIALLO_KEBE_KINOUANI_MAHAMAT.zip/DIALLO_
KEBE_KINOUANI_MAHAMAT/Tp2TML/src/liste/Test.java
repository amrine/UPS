package liste;

public class Test {
	
	static void insere(int x, Liste L) {
		Liste courant=L, precedent=null, nouveau;
		boolean continuer = true;
		
		//recherche emplacement et insertion
		while(continuer && courant != null){
			if(courant.getInfo() < x){
				precedent = courant;
				courant = courant.getSuiv();
			}else
				continuer = false;
		}
		//creation nouveau
		nouveau = new Liste(x, courant);
		
		//insertion du nouveau
		if(precedent == null){
			L = nouveau;
		}else{
			precedent.setSuiv(nouveau);
		}
		
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		insere(5,null);
		insere(4, new Liste(1, new Liste(5, null)));
	}

}

