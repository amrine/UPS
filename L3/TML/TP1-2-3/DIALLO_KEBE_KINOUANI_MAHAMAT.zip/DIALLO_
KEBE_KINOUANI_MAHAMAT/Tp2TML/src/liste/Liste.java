package liste;

public class Liste {
	private int info;
	private Liste suiv = null;
	
	public Liste(int info,Liste suiv){
		this.info=info;
		this.suiv=suiv;
	}
	public Liste getSuiv(){
		return this.suiv;
	}
	
	public int getInfo(){
		return this.info;
	}
	public void setSuiv(Liste l){
		this.suiv = l;
	}
}
