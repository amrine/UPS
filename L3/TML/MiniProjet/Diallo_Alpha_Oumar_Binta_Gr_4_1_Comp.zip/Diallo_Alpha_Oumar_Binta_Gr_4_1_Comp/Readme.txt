Diallo Alpha Oumar Binta
Groupe : 4.1
No etudiant :21007631

Test Junit4 sur Logisim :
les cas de tests et classe de test se trouve dans le package test
la fonctionnalit� F2 n'a pu �tre test� car elle n'�tait pas impl�ment�e.