Diallo Alpha Oumar Binta
Groupe : 4.1
No etudiant :21007631

Structure des cas de test dans les fichiers TestMOD et testSUM :
Les jeux de tests sont charg�s automatiquement, on peut rajouter d'autres jeux de test
� partir des fichiers afin de ne pas recompiler le projet.

fichier testMOD.txt:
6-1-4-jeu de test valide
Le premier chiffre repr�sente la valeur � tester
Le second chiffre repr�sente l'oracle
Le troisi�me chiffre repr�sente la taille des entr�es (ex: 0=(0000) en base 2, 4 bits)
Le dernier champ repr�sente le nom du test

fichier testSUM.txt:
6-10-16-4-jeu de test valide
Le premier chiffre repr�sente la premi�re entr�e
Le second chiffre repr�sente la seconde entr�e
Le troisi�me chiffre repr�sente l'oracle
Le quatri�me chiffre repr�sente la taille des entr�es (ex: 0=(0000) en base 2, 4 bits)
Le dernier champ repr�sente le nom du test

Les deux fichiers se trouvent dans le repertoire Fichier_test
Le script de test dans le package campagneTest sous le repertoire src/campagneTest