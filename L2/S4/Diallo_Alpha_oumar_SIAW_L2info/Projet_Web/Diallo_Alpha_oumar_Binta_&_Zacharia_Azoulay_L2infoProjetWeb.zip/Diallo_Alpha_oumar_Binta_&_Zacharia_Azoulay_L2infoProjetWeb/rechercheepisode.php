<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Recherche d'un Episode</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	   <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
		<?php include("/includes/menu.php"); ?>
		<p>
		<form action="resultrechercheepisode.php" method="get">
			<br/>
			<table class="table_simple" >
				<th> RECHERCHE D'EPISODE</th>
				<tr>
					<td> Nom de la S&eacute;rie : </td>
					<td> <input type="text" size="40" name="fnom" /> </td>
				</tr>
				<tr>
					<td> Saison :</td>
					<td> <input type="text" size="10" name="fsaison" /> </td>
				</tr>
				<tr>
					<td> Ann&eacute;e :</td>
					<td> <input type="text" size="10" name="fannee" /> </td>
				</tr>
				<tr>
					<td> Prix :</td>
					<td> <input type="text" size="10" name="fprix" /> </td>
				</tr>
				<tr>
					<td> Type de T&eacute;l&eacute;chargement : </td>
					<td> <input type="checkbox" name="fstreaming"/> streaming <br/>
					 	 <input type="checkbox" name="flocation"/> location <br/>
						 <input type="checkbox" name="fachat" /> achat</td>
				</tr>
				<tr><td><input type="submit" value="Rechercher" /></td>
				<td><input type="reset" value="Actualiser" /></td></tr>
			</table>
		</form>
		</p>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>
