<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>INSCRIPTION CLIENT</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	   <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
		<?php include("/includes/menu.php"); 
			 require_once("connect.php");
		?>
		<?php
		if (empty($_POST['fnom']) || empty($_POST['fprenom']) || empty($_POST['fdate']) || empty($_POST['fpays'])){
			echo "<p><br/><center><h2>Aucune donn&eacute;e entr&eacute;e</h2><a href='inscription.php'>Recommencer</a></center></p>";  
		}else{
			$vprenom=$_POST['fprenom'];
			$vnom=$_POST['fnom'];
			$vdate=$_POST['fdate'];
			$vpays=$_POST['fpays'];
			$requete="insert into clients (nom, prenom,daten,pays) values ('$vnom','$vprenom','$vdate','$vpays')";
			mysql_query($requete,$connexion);
			echo "<p><center><br/><h2>L'inscription a &eacute;t&eacute; r&eacute;alis&eacute;e avec succ&egrave;s<br/>
			Bienvenue (Mr/mme) $vnom $vprenom</h2></center></p>";
		}
		?>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>
