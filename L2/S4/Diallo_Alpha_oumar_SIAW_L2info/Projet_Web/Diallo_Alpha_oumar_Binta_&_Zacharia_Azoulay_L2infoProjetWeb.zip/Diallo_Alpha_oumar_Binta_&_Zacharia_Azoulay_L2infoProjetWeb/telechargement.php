<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>T&eacute;l&eacute;chargement</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
       <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
        <?php include("/includes/menu.php"); ?>
        <p>
        <form action="confirmation.php" method="get">
            <br/>
            <table class="table_simple" >
                <th> FORMULAIRE DE TELECHARGEMENT</th>
                 <tr><td> Num&eacute;ro de l'&eacute;pisode :</td>
                    <td> <input type="text" size="10" name="fnumero" /> </td>
                </tr>
                <tr>
                    <td> Type de T&eacute;l&eacute;chargement : </td>
                    <td> <input type="radio" name="ftype" value="S"/> streaming <br/>
                         <input type="radio" name="ftype" value="L"/> location <br/>
                         <input type="radio" name="ftype" value="A" /> achat</td>
                </tr>
                <tr><tr><td> Num&eacute;ro du Client</td>
                    <td> <input type="text" size="10" name="fclient" /> </td>
                </tr>
                <tr><td><input type="submit" value="T&eacute;l&eacute;charg&eacute;" /></td>
                <td><input type="reset" value="Actualiser" /></td></tr>
            </table>
        </form>
        </p>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>