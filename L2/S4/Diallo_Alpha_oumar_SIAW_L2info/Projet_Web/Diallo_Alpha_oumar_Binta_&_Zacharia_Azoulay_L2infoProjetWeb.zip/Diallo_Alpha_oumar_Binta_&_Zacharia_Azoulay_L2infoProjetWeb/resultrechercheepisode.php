<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Recherche d'une S&eacute;rie</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
       <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
        <?php include("/includes/menu.php"); ?>
        <?php
            require_once("connect.php");
            require_once("fonctions.php");
            if (!empty($_GET['fnom'])) {
                $vnom = $_GET['fnom'];
            }
            if (!empty($_GET['fsaison'])) {
                $vsaison = $_GET['fsaison'];
            }
            if (!empty($_GET['fannee'])) {
                $vannee = $_GET['fannee'];
            }
            if (!empty($_GET['fprix'])) {
                $vprix= $_GET['fprix'];
            }
            
            $test= true;
            if (empty($_GET['fnom']) && empty($_GET['fsaison']) && empty($_GET['fannee']) && !empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and prix<=$vprix";
            } elseif (empty($_GET['fnom']) && empty($_GET['fsaison']) && !empty($_GET['fannee']) && empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and annee=$vannee";
            } elseif (empty($_GET['fnom']) && empty($_GET['fsaison']) && !empty($_GET['fannee']) && !empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and annee=$vannee and prix<=$vprix";
            } elseif (empty($_GET['fnom']) && !empty($_GET['fsaison']) && empty($_GET['fannee']) && empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and saison=$vsaison";
            } elseif (empty($_GET['fnom']) && !empty($_GET['fsaison']) && empty($_GET['fannee']) && !empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and saison=$vsaison and prix<=$vprix";
            } elseif (empty($_GET['fnom']) && !empty($_GET['fsaison']) && !empty($_GET['fannee']) && empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and saison=$vsaison and annee=$vannee";
            } elseif (empty($_GET['fnom']) && !empty($_GET['fsaison']) && !empty($_GET['fannee']) && !empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and saison=$vsaison and annee=$vannee and prix<=$vprix";
            } elseif (!empty($_GET['fnom']) && empty($_GET['fsaison']) && empty($_GET['fannee']) && empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and noms like '%$vnom%'";
            } elseif (!empty($_GET['fnom']) && empty($_GET['fsaison']) && empty($_GET['fannee']) && !empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and noms like '%$vnom%' and prix<=$vprix";
            } elseif (!empty($_GET['fnom']) && empty($_GET['fsaison']) && !empty($_GET['fannee']) && empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and noms like '%$vnom%' and annee=$vannee";
            } elseif (!empty($_GET['fnom']) && empty($_GET['fsaison']) && !empty($_GET['fannee']) && !empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and noms like '%$vnom%' and annee=$vannee and prix<=$vprix";
            } elseif (!empty($_GET['fnom']) && !empty($_GET['fsaison']) && empty($_GET['fannee']) && empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and noms like '%$vnom%' and saison=$vsaison";
            } elseif (!empty($_GET['fnom']) && !empty($_GET['fsaison']) && empty($_GET['fannee']) && !empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and noms like '%$vnom%' and saison=$vsaison and prix<=$vprix";
            } elseif (!empty($_GET['fnom']) && !empty($_GET['fsaison']) && !empty($_GET['fannee']) && empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and noms like '%$vnom%' and saison=$vsaison and annee=$vannee";
            } elseif (!empty($_GET['fnom']) && !empty($_GET['fsaison']) && !empty($_GET['fannee']) && !empty($_GET['fprix'])){
                $condition ="where series.cs=episodes.cs and episodes.ce=fichiers.ce and noms like '%$vnom%' and saison=$vsaison and annee=$vannee and prix<=$vprix";
            } elseif (empty($_GET['fnom']) && empty($_GET['fsaison']) && empty($_GET['fannee']) && empty($_GET['fprix'])){
                $condition ="";
                $test= false;
            }
            
            if ($test){
            $first = true;
            $fich = "";
            if (!empty($_GET['fstreaming'])) {
                $fich = "type='S'";
                $first = false;
            }
            if (!empty($_GET['flocation'])) {
                if (!$first) {
                    $fich = $fich." OR type='L'";
                } else {
                    $fich = "type='L'";
                    $first = false;
                }
            }
            if (!empty ($_GET['fachat'])) {
                if (!$first){
                    $fich = $fich." OR type='A'";}
                else {
                    $fich = "type='A'";
                    $first = false;}
            }
            if (!$first)
            $condition = $condition."AND ($fich)";
            
            //on affiche le resultat
            $requete="select titre,noms,series.image as 'image',episodes.image as 'image_episode',saison,annee,realisateur,de,episodes.ce as num_episode,numero
            from series,episodes,fichiers $condition group by titre";
            $resultat = mysql_query($requete,$connexion);
            echo "<br/><br/>";
                                    
                //on affiche le resultat
				$cpt=0;
                while ( $lignesepisode = mysql_fetch_object($resultat)){
					$cpt++;
					if ($cpt == 1){
						echo " <table class='table_cadre'>
                            <caption>R&eacute;sultat De le Recherche</caption>
                            <tr><td colspan='2'> Titre de l'Episode </td>
                                <td> Num&eacute;ro dans la base </td>
                                <td> Nom de la S&eacute;rie </td>
                                <td> Num&eacute;ro de l'Episode </td>
                                <td> Ann&eacute;e </td>
                                <td> Saison </td>
                                <td> R&eacute;alisateur </td>
                                <td> Dur&eacute;e </td>
                                <td> Prix en Streaming </td>
                                <td> Prix en Location </td>
                                <td> Prix en Achat </td></tr>"; 
					}
				if ($lignesepisode->image_episode == NULL) $lignesepisode->image_episode = $lignesepisode->image;
                    AfficheEpisodeComplet($lignesepisode,$connexion);
                 }
				 if ($cpt != 0){   
					 echo "</table>";
					echo "<br/><br/>";
			} elseif ($cpt==0){
					echo "<p><center><br/><h2>Aucun R&eacute;sultat Trouv&eacute;</h2></center></p>";
			}
            }
            else echo "<p><center><br/><h2>Aucune Donn&eacute;e Entr&eacute;e Veuillez Remplir les Champs</h2></center></p>";
        ?>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>


