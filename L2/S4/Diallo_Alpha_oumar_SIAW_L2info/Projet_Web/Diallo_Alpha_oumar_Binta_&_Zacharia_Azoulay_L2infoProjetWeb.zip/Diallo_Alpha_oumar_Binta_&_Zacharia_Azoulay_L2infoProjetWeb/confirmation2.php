<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Recherche d'une S&eacute;rie</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
       <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
        <?php include("/includes/menu.php"); ?>
        <?php
            require_once("connect.php");
            require_once("fonctions.php");
		$x=0;
		if (empty($_GET['ftype'])) {
			echo "<p><center><br/><h2>Vous devez faire un choix</h2></center></p>";
			$x=1;
			}
		if ($x==0){
			$vclient= $_GET['fclient'];
			$vnum = $_GET['fnumero'];
			$vtype = $_GET['ftype'];
			$codefich = mysql_query("select cf  from fichiers where ce=$vnum and type='$vtype' ",$connexion);
			$vcfich = mysql_fetch_object($codefich) ;
			$vdate=date('Y-m-d');
		
		
		
			$requete2="insert into Telecharger values ($vclient, $vnum, $vdate, 10)";
			mysql_query($requete2,$connexion);
			echo "<p><center><br/><h2>La t&eacute;l&eacute;chargement a &eacute;t&eacute; effectu&eacute; avec succ&egrave;s</h2></center></p>";
			}
	
        ?>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>