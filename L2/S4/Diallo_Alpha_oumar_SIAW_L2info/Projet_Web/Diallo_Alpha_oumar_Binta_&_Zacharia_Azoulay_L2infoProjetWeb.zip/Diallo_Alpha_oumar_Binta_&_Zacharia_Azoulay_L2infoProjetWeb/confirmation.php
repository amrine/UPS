<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Recherche d'une S&eacute;rie</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
       <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
        <?php include("/includes/menu.php"); ?>
        <?php
            require_once("connect.php");
            require_once("fonctions.php");
            $x=0;
		if (empty($_GET['fclient']) || empty($_GET['ftype']) || empty($_GET['fnumero']) ) {
				$x=1;
				echo "<p><center><br/><h2>Veuillez Remplir tous les Champs</h2></center></p>";
		}
		if (!empty($_GET['fclient'])) {
		    $vclient= $_GET['fclient'];
                    $testclient = mysql_query("select cc  from clients where cc=$vclient",$connexion);
                    $test2 = mysql_fetch_object($testclient) ;
                    if (!$test2) {
		    echo "<p><br/><center><a href='inscription.php'>Cet identifiant n'existe pas cliquer ici pour vous inscrire</a></center></p>";
		    $x=1;
		    }
		}
		if (!empty($_GET['fnumero'])) {
		    $vnum= $_GET['fnumero'];
                    $testepi = mysql_query("select ce  from fichiers where ce=$vnum",$connexion);
                    $appartient = mysql_fetch_object($testepi) ;
                    if (!$appartient){
			echo "<p><br/><center><a href='telechargement.php'>Cet &eacute;pisode n'existe pas cliquer ici pour vous reprendre</a></center></p>";
			$x=1;
			}
		}	
		if ((!empty($_GET['fnumero'])) && $x==0) {
				$vnum = $_GET['fnumero'];
				$vtype = $_GET['ftype'];
				$testepisode = mysql_query("select ce  from fichiers where ce=$vnum and type='$vtype' ",$connexion);
				$test = mysql_fetch_object($testepisode) ;
                if (!$test) {
					
                     $requete= mysql_query("select type from fichiers where ce=$vnum group by type",$connexion);
		     echo "<p><br/><center><h4>Ce fichier n'est disponible que dans les formats :</h4>";
		     echo "<form action='confirmation2.php' method='get'>
		     <input type='hidden'  name='fnumero' value='$vnum' /><input type='hidden' name='fclient' value='$vclient' />";
                     while ($resultat = mysql_fetch_object($requete) ){
			AfficheType($resultat); 
			}
			echo "<br/><br/><input type='submit' value='valider' /><input type='reset' value='Actualiser' /></form></center></p>";	
			$x=1;
                }
		}
		if ($x == 0){
			$codefich = mysql_query("select cf  from fichiers where ce=$vnum and type='$vtype' ",$connexion);
			$vcfich = mysql_fetch_object($codefich) ;
			$vdate=date('Y-m-d');
			$requete2="insert into Telecharger values ($vclient, $vnum, $vdate, 10)";
			mysql_query($requete2,$connexion);
			echo "<p><center><br/><h2>La t&eacute;l&eacute;chargement a &eacute;t&eacute; effectu&eacute; avec succ&egrave;s</h2></center></p>";
		}
	
        ?>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>