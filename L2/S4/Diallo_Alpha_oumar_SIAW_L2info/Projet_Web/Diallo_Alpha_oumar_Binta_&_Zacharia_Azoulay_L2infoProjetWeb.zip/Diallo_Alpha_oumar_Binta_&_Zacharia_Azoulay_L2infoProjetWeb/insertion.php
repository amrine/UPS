<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>INSERTION </title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	   <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
		<?php include("/includes/menu.php"); 
			 require_once("connect.php");
		?>
		<?php
			if(!empty($_POST['fpass']) && $_POST['fpass']=="webmaster"){ 
				echo "
				<div id= 'par2'><div id='gauche'>
				<p>
					<form action='confirmationinsertion.php' method='post'>
					<br/>
						<table class='table_simple' >
							<th>INSERTION DE SERIE</th>
							<tr><td> Nom de la serie : </td>
							<td> <input type='text' name='fnom' /> </td>
							</tr>
							<tr><td> Type de la serie : </td>
							<td> <input type='radio' name='ftype' value='A'/> animation <br/>
							<input type='radio' name='ftype' value='P'/> policier <br/>
							<input type='radio' name='ftype' value='D' /> documentaire<br/>
							<input type='radio' name='ftype' value='F' /> fiction<br/></td>
							</tr>
							<tr><td> Image de la s&eacute;rie : </td>
							<td> <input type='text'  name='fimage' /> </td>
							</tr>
							<tr><td><input type='submit' value='Ins&eacute;rer' /></td>
							</tr>
						</table>
					</form>
				</p></div><div id='droite'>
				<p>
					<form action='confirmationinsertionepisode.php' method='post'>
					<br/>
						<table class='table_simple' >
							<th>INSERTION D'EPISODE</th>
							<tr><td> titre : </td>
							<td> <input type='text' name='ftitre' /> </td></tr>
							<tr><td> Nom de la S&eacute;rie : </td>
							<td> <input type='text'  name='fnom' /> </td>
							</tr>
							<tr><td> Num&eacute;ro : </td>
							<td> <input type='text'  name='fnumero' /> </td>
							</tr>
							<tr><td> Ann&eacute;e : </td>
							<td> <input type='text'  name='fannee' /> </td>
							</tr>
							<tr><td> Saison : </td>
							<td> <input type='text'  name='fsaison' /> </td>
							</tr>
							<tr><td> R&eacute;alisateur : </td>
							<td> <input type='text'  name='freal' /> </td>
							</tr>
							<tr><td> Dur&eacute;e : </td>
							<td> <input type='text'  name='fduree' /> </td>
							</tr>
							<tr><td> Public Vis&eacute;: </td>
							<td> <input type='text'  name='fpublic' /> </td>
							</tr>
							<tr><td> Image : </td>
							<td> <input type='text'  name='fimage' /> </td>
							</tr>
							<tr><td><input type='submit' value='Ins&eacute;rer' /></td>
							</tr>
						</table>
					</form>
				</p>
				</div></div>";
			}else{
			
				echo "<p><br/><h3><center>Mot de passe incorrect <a href='prive.php'>retour au login</a></center></h3></p>";
			}
		?>
   </body>
</html>
