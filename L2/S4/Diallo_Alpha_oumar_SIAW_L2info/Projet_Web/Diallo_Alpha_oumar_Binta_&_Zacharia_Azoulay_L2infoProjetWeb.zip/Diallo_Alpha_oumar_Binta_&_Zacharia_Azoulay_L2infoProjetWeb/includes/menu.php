   <table id="entete">
   <tr>
   <td><img src="./images/logo.jpg" class="img_logo" alt="logo"/></td>
   <td><h2>SuperVod : les meilleures s&eacute;ries sont chez nous !</h2></td>
   <td><img src="./images/logo.jpg" class="img_logo" alt="logo"/></td>
   </tr>
   </table>
   <div id="menu">
   	<ul class="contenu_menu">
			<li><a href="acceuil.php">Nouveaut&eacute;</a> </li>
			<li><a href="rechercheserie.php">Recherche d'une serie</a> </li>
			<li><a href="rechercheepisode.php">Recherche d'un episode</a> </li>
			<li><a href="telechargement.php">T&eacute;l&eacute;chargement</a> </li>
			<li><a href="prive.php">Administrateur</a> </li>
		</ul>
	</div>

