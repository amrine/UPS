<div id="pied">
	<p><br/><br/><br/><br/>Projet SIAW 2010-2011 Universit&eacute; Paul Sabatier<br/>Zacharia Azoulay - Diallo Alpha Oumar Binta<br/>
		<img src="./images/valid.png" alt="Valid XHTML 1.0 Strict" height="31" width="88" />
	</p>
</div>

