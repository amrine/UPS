<?php
	//fichier contenant les constantes de connexion
	define ('NOM',"root");
	define ('PASSE',"");
	define ('SERVEUR',"127.0.0.1");
	define ('BASE',"vod");
?>
<?php
	$connexion = mysql_pconnect(SERVEUR,NOM,PASSE);
	if (!$connexion) {
		echo "D&eacute;sol&eacute;, connection &agrave; ".SERVEUR." impossible <br/>";
	}
	if (!mysql_select_db(BASE,$connexion)) {
		echo "<br/>D&eacute;sol&eacute;, acc&egrave;s &agrave; la base ".BASE." impossible <br/>";
		exit;
	}
?>
