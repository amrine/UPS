<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>INSERTION DE NOUVELLE SERIE</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	   <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
		<?php include("/includes/menu.php"); 
			 require_once("connect.php");
		?>
		<?php
		$x=0;
		if (empty($_POST['ftitre']) || empty($_POST['fnom']) || empty($_POST['fnumero']) || empty($_POST['fannee']) || empty($_POST['fsaison'])
		 || empty($_POST['freal']) || empty($_POST['fduree']) || empty($_POST['fpublic']) || empty($_POST['fimage'])){
			$x=1;
			echo "<p><br/><center><h2>Aucune donn&eacute;e entr&eacute;e</h2><a href='prive.php'>Recommencer</a></center></p>";  
		}else{
		
			$vnom=$_POST['fnom'];
			$codeserie = mysql_query("select cs  from series where noms like '%$vnom%'",$connexion);
			$code = mysql_fetch_object($codeserie) ;
			if (!$code) {
				$x=1;
				echo "<p><br/><center><h2>Cette S&eacute;rie n'exixte pas Veuillez la rajouter avant de continuer</h2><a href='prive.php'>Recommencer</a></center></p>";
				}
			if ($x == 0){
			
			$vtitre=$_POST['ftitre'];
			$vnum=$_POST['fnumero'];
			$vannee=$_POST['fannee'];
			$vsaison=$_POST['fsaison'];
			$vreal=$_POST['freal'];
			$vduree=$_POST['fduree'];
			$vpublic=$_POST['fpublic'];
			$vimage=$_POST['fimage'];
			$requete="insert into Episodes (titre, cs, numero, annee, saison, realisateur, de, lim, image) values ('$vtitre',$code->cs,$vnum,$vannee,$vsaison, '$vreal',$vduree,$vpublic,'images/$vimage')";
	
			mysql_query($requete,$connexion);
			echo "<p><center><br/><h2>La s&eacute;rie a &eacute;t&eacute; ajout&eacute; avec succ&egrave;s</h2></center></p>";
			}
		}
		?>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>

			