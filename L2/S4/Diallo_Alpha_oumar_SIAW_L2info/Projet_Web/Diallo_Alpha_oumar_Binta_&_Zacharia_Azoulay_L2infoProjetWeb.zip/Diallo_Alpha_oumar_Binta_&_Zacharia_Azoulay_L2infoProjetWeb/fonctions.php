<?php

function AfficheSerie ($ligneserie,$variabledeconnection){
    echo "<tr><td> <img src=$ligneserie->image alt='image'  width='20px' height='20px' /> </td>
             <td> $ligneserie->noms </td>
             <td> $ligneserie->types </td>
             <td> $ligneserie->nbsaison </td>
             <td> $ligneserie->nbepisode </td>
            </tr>";
    }
function AfficheSerie2 ($ligneserie,$variabledeconnection){
    echo "<tr><td colspan='3'> <img src=$ligneserie->image alt='image'  width='20px' height='20px' /> </td>
             <td colspan='5'> $ligneserie->noms </td>
             <td> $ligneserie->types </td>
             <td> $ligneserie->nbsaison </td>
             <td> $ligneserie->nbepisode </td>
            </tr>";	
	}

function AfficheEpisode($ligneepisode,$ligneserie){
	if ($ligneepisode->image_episode == NULL) {
		$ligneepisode->image_episode = $ligneserie->image;
	}
    echo "<tr><td> <img src=$ligneepisode->image_episode alt='image'  width='20px' height='20px' /></td>
            <td> $ligneepisode->nber </td>
            <td> $ligneepisode->titre </td>
            <td> $ligneepisode->numero </td>
            <td> $ligneepisode->annee </td>
            <td> $ligneepisode->saison </td>
            <td> $ligneepisode->realisateur </td>
            <td> $ligneepisode->de </td>
            <td> $ligneepisode->lim </td>
            </tr>"; 
}
function AfficheEpisodeComplet($ligneepisode,$variabledeconnection){

  echo "<tr><td> <img src=$ligneepisode->image_episode alt='image'  width='20px' height='20px' /></td>
                 <td> $ligneepisode->titre </td>
            <td> $ligneepisode->num_episode </td>
            <td> $ligneepisode->noms </td>
            <td> $ligneepisode->numero </td>
            <td> $ligneepisode->annee </td>
            <td> $ligneepisode->saison </td>
            <td> $ligneepisode->realisateur </td>
            <td> $ligneepisode->de </td>";

         $prix1 = mysql_query("select prix  from  fichiers where fichiers.ce =$ligneepisode->num_episode  and type='S'",$variabledeconnection);
         $prix2 = mysql_query("select prix  from  fichiers where fichiers.ce =$ligneepisode->num_episode and type='L'",$variabledeconnection);
         $prix3 = mysql_query("select prix  from  fichiers where fichiers.ce =$ligneepisode->num_episode and type='A'",$variabledeconnection);


        if ($prix_s = mysql_fetch_object($prix1))  echo "<td> $prix_s->prix </td>"; else echo "<td>N/A</td>";
        if ($prix_l = mysql_fetch_object($prix2))  echo "<td> $prix_l->prix </td>"; else echo "<td>N/A</td>";
        if ($prix_a = mysql_fetch_object($prix3))  echo "<td> $prix_a->prix </td>"; else echo "<td>N/A</td>";
        echo "</tr>";
}

function AfficheType ($ligneserie){
    echo "<input type='radio' name='ftype' value='$ligneserie->type'/>$ligneserie->type";
    }
?>