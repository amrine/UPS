<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Recherche d'une S&eacute;rie</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	   <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
		<?php include("/includes/menu.php"); ?>
		<p>
		<form action="resultrechercheserie.php" method="get">
			<br/>
			<table class="table_simple" >
				<th> RECHERCHE DE SERIE</th>
				<tr>
					<td> Nom de la S&eacute;rie : </td>
					<td> <input type="text" size="40" name="fnom" /> </td>
				</tr><tr>
					<td> Ann&eacute;e :</td>
					<td> <input type="text" size="10" name="fannee" /> </td>
				</tr><tr>
					<td> Type : </td>
					<td> <input type="radio" name="ftype" value="A"  /> Anim&eacute;e <br/>
					 	 <input type="radio" name="ftype" value="P" /> Policier <br/>
						 <input type="radio" name="ftype" value="D" /> Documentaire <br/>
					 	 <input type="radio" name="ftype" value="F" /> Fiction </td>
				</tr>
				<tr>
					<td> Public Avis&eacute; : </td>
					<td> <select name="fage" >
							<option value="0">+00</option>
							<option value="10">+10</option>
							<option value="12">+12</option>
							<option value="16">+16</option>
							</select>
					</td>
				</tr>
				<tr><td><input type="submit" value="Rechercher" /></td>
				<td><input type="reset" value="Actualiser" /></td></tr>
			</table>
		</form>
		</p>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>
