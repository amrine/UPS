<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>INSCRIPTION</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
       <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
        <?php include("/includes/menu.php"); ?>
        <p>
        <form action="confirmationclient.php" method="post">
            <br/>
            <table class="table_simple" >
                <th> FORMULAIRE D'INSCRIPTION</th>
                 <tr><td> Votre Nom :</td>
                    <td> <input type="text" size="10" name="fnom" /> </td>
                </tr>
                <tr><td>Votre Pr&eacute;nom :</td>
                    <td> <input type="text" size="10" name="fprenom" /> </td>
                </tr>
		<tr><td> Date de naissance (annee-mois-jour):</td>
                    <td> <input type="date" size="10" name="fdate"  /> </td>
                </tr>
		<tr><td> Votre Pays :</td>
                    <td> <input type="text" size="10" name="fpays" /> </td>
                </tr>
                <tr><td><input type="submit" value="s'inscrire" /></td>
                <td><input type="reset" value="Actualiser" /></td></tr>
            </table>
        </form>
        </p>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>