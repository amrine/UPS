<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Bienvenue chez Super Vod !</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
       <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
        <?php include("/includes/menu.php"); ?>
        <p>
            <?php
                require_once("connect.php");
                require_once("fonctions.php");
            $requete = "SELECT noms,types,series.image as 'image',count(DISTINCT(saison)) as 'nbsaison',count(titre) as 'nbepisode'
                        FROM series, episodes
                        WHERE series.cs = episodes.cs
                        group by noms";
            //execution de la requete
            $resultat = mysql_query($requete,$connexion);
            echo "<br/>";
            if ($resultat){
                echo " <table class='table_cadre'>
                            <caption>Liste des S&eacute;ries Disponible</caption>
                            <tr><td colspan='2'> Nom </td>
                                <td> Type </td>
                                <td> Nombre de Saison </td>
                                <td> Nombre d'Episode </td></tr>";
                //on affiche le resultat
                while ( $ligneserie = mysql_fetch_object($resultat)){
                 AfficheSerie ($ligneserie,$resultat); 
                 }
                echo "</table>";
            }
            ?>
        </p>
		<?php include("/includes/pied_de_page.php"); ?>
   
   </body>
</html>