<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>PRIVE</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
       <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
        <?php include("/includes/menu.php"); ?>
        <p>
        <form action="insertion.php" method="post">
            <br/>
            <table class="table_simple" >
                <th> CONNEXION</th>
                 <tr><td> Pseudo :</td>
                    <td> <input type="text" size="18" name="fnom" value="prive pass(webmaster)" /> </td>
					</tr>
                <tr><td> mot de passe :</td>    <td> <input type="password" size="10" name="fpass" /> </td>
                </tr>
                <tr><td><input type="submit" value="Valider" /></td>
                <td><input type="reset" value="Actualiser" /></td></tr>
            </table>
        </form>
        </p>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>