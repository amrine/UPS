<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>INSERTION DE NOUVELLE SERIE</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	   <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
		<?php include("/includes/menu.php"); 
			 require_once("connect.php");
		?>
		<?php
		if (empty($_POST['fimage']) || empty($_POST['fnom']) || empty($_POST['ftype'])){
			echo "<p><br/><center><h2>Aucune donn&eacute;e entr&eacute;e</h2><a href='prive.php'>Recommencer</a></center></p>";  
		}else{
			$image=$_POST['fimage'];
			$nom=$_POST['fnom'];
			$type=$_POST['ftype'];
			$requete="insert into Series (noms, types,image) values ('$nom','$type','images/$image')";
			mysql_query($requete,$connexion);
			echo "<p><center><br/><h2>La s&eacute;rie a &eacute;t&eacute; ajout&eacute; avec succ&egrave;s</h2></center></p>";
		}
		?>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>
