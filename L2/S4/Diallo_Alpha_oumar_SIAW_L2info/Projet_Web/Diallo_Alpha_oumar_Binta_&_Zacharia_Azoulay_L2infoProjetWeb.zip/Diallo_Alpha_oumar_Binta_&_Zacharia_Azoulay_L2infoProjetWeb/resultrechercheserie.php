<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Recherche d'une S&eacute;rie</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
       <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>
        <?php include("/includes/menu.php"); ?>
        <?php
            require_once("connect.php");
            require_once("fonctions.php");
            if (!empty($_GET['fnom'])) {
                $vnom = $_GET['fnom'];
            }           
            if (!empty($_GET['fannee'])) {
                $vannee = $_GET['fannee'];
            }
            if (!empty($_GET['ftype'])) {
                $vtype= $_GET['ftype'];
            }
            $test= true;
            if (empty($_GET['fnom']) && empty($_GET['fannee']) && !empty($_GET['ftype'])){
                $condition ="where series.cs=episodes.cs and types='$vtype'";
            } elseif (empty($_GET['fnom']) && !empty($_GET['fannee']) && empty($_GET['ftype'])){
                $condition ="where series.cs=episodes.cs and annee=$vannee";
            } elseif (empty($_GET['fnom']) && !empty($_GET['fannee']) && !empty($_GET['ftype'])){
                $condition ="where series.cs=episodes.cs and annee=$vannee and types='$vtype'";
            } elseif (!empty($_GET['fnom']) && empty($_GET['fannee']) && empty($_GET['ftype'])){
                $condition ="where series.cs=episodes.cs and noms like '%$vnom%'";
            } elseif (!empty($_GET['fnom']) && empty($_GET['fannee']) && !empty($_GET['ftype'])){
                $condition ="where series.cs=episodes.cs and noms like '%$vnom%' and types='$vtype'";
            } elseif (!empty($_GET['fnom']) && !empty($_GET['fannee']) && empty($_GET['ftype'])){
                $condition ="where series.cs=episodes.cs and noms like '%$vnom%' and annee=$vannee";
            } elseif (!empty($_GET['fnom']) && !empty($_GET['fannee']) && !empty($_GET['ftype'])){
                $condition ="where series.cs=episodes.cs and noms like '%$vnom%' and annee=$vannee and types='$vtype'";
            } elseif (empty($_GET['fnom']) && empty($_GET['fannee']) && empty($_GET['ftype'])){
                $condition ="";
                $test= false;
            }
            
			
            if ($test){
            $condition2 = "";
            if (!empty($_GET['fage'])) {
                $type = $_GET['fage'];
				$condition2 = "AND lim >=$type";
            }
			$condition = $condition." $condition2 "; 			
            //on affiche le resultat
            $requete="select noms,types,series.image as 'image',count(DISTINCT(saison)) as 'nbsaison',count(titre) as 'nbepisode',series.cs as 'code'
            from series,episodes $condition group by noms ";
            
            $resultat = mysql_query($requete,$connexion);

            echo "<br/><br/>";
            
                                       
                //on affiche le resultat
				$cpt=0;
                while ( $ligneserie = mysql_fetch_object($resultat)){
				 $cpt++;
				 if ($cpt == 1){
					echo " <table class='table_cadre'>
                            <caption>R&eacute;sultat De le Recherche</caption>
                            <tr><td colspan='8'> Nom </td>
                                <td> Type </td>
                                <td> Nombre de Saison </td>
                                <td> Nombre total d'Episode </td></tr>"; 
				 }
                 AfficheSerie2($ligneserie,$resultat); 

            $requete2="select episodes.image as 'image_episode',episodes.ce as 'nber',titre,numero,annee,saison,realisateur,de,lim
            from series,episodes $condition and episodes.cs = $ligneserie->code ";
            $resultat2 = mysql_query($requete2,$connexion);
                    echo "<td colspan='11'><table class='table_cadre'>";
                        while ( $ligneserie2 = mysql_fetch_object($resultat2)){ 
                            AfficheEpisode($ligneserie2,$ligneserie); 
                        }
                    echo "</td></table>";
                 }
            if ($cpt != 0){   
					echo "</table>";
					echo "<br/><br/>";
			} elseif ($cpt==0){
					echo "<p><center><br/><h2>Aucun R&eacute;sultat Trouv&eacute;</h2></center></p>";
			}
            }
            else echo "<p><center><br/><h2>Aucune Donn&eacute;e Entr&eacute;e Veuillez Remplir les Champs</h2></center></p>";
        ?>
		<?php include("/includes/pied_de_page.php"); ?>
   </body>
</html>